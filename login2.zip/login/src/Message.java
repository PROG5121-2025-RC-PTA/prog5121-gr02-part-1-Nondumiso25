import java.io.FileWriter;
import java.io.IOException;
import org.json.JSONObject;


public class Message {

    static String returnTotalMessages() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static String sendMessage(String store) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    private String messageId;
    private static int messageCount = 0;
    private int messageNumber;
    private String receiver;
    private String messagetText;
    private String messageHash;
    
    public Message(String receiver, String messageText){
        this.messageId = generateMessageId();
        this.receiver = receiver;
        this.messagetText= messageText;
        this.messageNumber = ++messageCount;
        this.messageHash = createMessageHash();
        
    }
    private String generateMessageId(){
      long number = (long)(Math.random()*1_000_000_0000L);
      return String.format("%010d", number);
        
    }
    public boolean checkMessageID(){
        return messageId.length() == 10;
    }
    
    public boolean checkReceiverCell(){
        return receiver.matches("^\\+\\d(10,13)$");
    }
    public String createMessageHash(){
        String messageText = "";
       String[] words = messageText.trim().split("\\s+");
        String first = words [0].toUpperCase();
        String last = words [words.length -1].toUpperCase();
        return messageId.substring(0,2)+":"+ messageNumber + first+ last;
    }
    public String sentMessage(String action){
        switch (action.toLowerCase()){
            case "send":
                return "Message successfully sent";
             case"delete" :
                 return "Press 0 to delete message";
             case "store":
                 StoreMessageToJson();
                 return "Message sucessfully stored";
             default:
                 return "Invalid action";
                
        }
    }
    public void storeMessageToJson(){
        try {
           JSONObject obj = new JSONObject();
           obj.put("messageID", messageId);
           obj.put("messageHash", messageHash);
           obj.put("Receiver", receiver);
            boolean messageText = false;
           obj.put("message", messageText);
           
           FileWriter file = new FileWriter("storedMessage.json", true);
           file.write(obj.toString() + System.lineSeparator());
           file.close();
        }catch(IOException e){
            System.out.println("Error saving message to JSON :" + e.getMessage());
        }
    }
    public String printMessageDetails(){
        String messageText = null;
        return "MessageID:" + messageId +
                "\nMessageHash:" + messageHash +
                "\nReceiver:" + receiver +
                "\nMessage:" + messageText;
    }
    public static int returnTotalMessage(){
        return messageCount;
    }

    private void StoreMessageToJson() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
