/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package mainQuick;

import javax.swing.JOptionPane;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author RC_Student_lab
 */
public class QuickChatAppTest {
    
    public QuickChatAppTest() {
    }

    @Test
    public void testMain() {
        
    }
         private static boolean login(){
        String username = JOptionPane.showInputDialog("Enter username");
        String password = JOptionPane.showInputDialog("Enter password");
        
        
        if (username != null && password != null && username.equals("username") && password.equals("jwiiwhdidh")) {
            JOptionPane.showMessageDialog(null, "Login successful");
        } else {
            JOptionPane.showMessageDialog(null, "Invalid username or password");
    }
        return false;
    }
    }
    

