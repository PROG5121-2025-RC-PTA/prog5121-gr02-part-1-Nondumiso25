
package login;
import javax.swing.JOptionPane;
import java.util.regex.Pattern;

public class Login {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String username ="";
        String password ="";
        String phoneNumber  = "";
       String login ="";
       
        username = JOptionPane.showInputDialog("Enter your username ");
        
        if (username!= null && CheckeUserName(username))
        {
            JOptionPane.showMessageDialog(null,"Valid username");
        }else{
            JOptionPane.showMessageDialog(null,"Invalid username");
        }
        
        password = JOptionPane.showInputDialog("Enter your Password ");
        
        if (password!= null && CheckerPasswordComplexity(password))
        {
            JOptionPane.showMessageDialog(null,"Valid Password");
        }else{
            JOptionPane.showMessageDialog(null,"Invalid Password!");
        }
        
         phoneNumber = JOptionPane.showInputDialog("Enter your Phone Number");
         
        if (phoneNumber!= null && checkPhoneNumber(phoneNumber))
        {
            JOptionPane.showMessageDialog(null,"login succesful");
        }else{
            JOptionPane.showMessageDialog(null,"Invalid phoneNumber!");
        }
       
    }
    public static boolean CheckeUserName (String username )
    {
        boolean hasUnderscore = username.contains("_");
        int maxLength = 5;
        return false;
    }
    public static boolean CheckerPasswordComplexity (String password )
    {
     if(password.length()<8){
         return true;}
     else {
         boolean hasUpperCase = true;
         boolean hasNumber = true;
         boolean hasSpecailChar = true;
     }
        return false;
                 
     }

    private static boolean checkPhoneNumber(String phoneNumber) {
        return phoneNumber.length()== 12;
        
    }
         
   
}
