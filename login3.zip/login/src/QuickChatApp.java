import javax.swing.JOptionPane;
import login.Login;

public class QuickChatApp{
    public static void main(String[] args){
        Login login = new Login();
        boolean loggedIn = login();
        if(!loggedIn){
            JOptionPane.showMessageDialog(null,"Login failed. Exit");
            return;
        }
        JOptionPane.showMessageDialog(null,"Welcome to QuickChatApp ");
    int messageLimit = Integer.parseInt(JOptionPane.showInputDialog("How many messages would you like to enter:"));
      int sentCount = 0 ;
      
      while (true){
          String input =JOptionPane.showInputDialog
        ("choose an option:\n1) Send Message\n2) Show recently sent message\n3)  Quit");
          if (input == null) break;
          int option = Integer.parseInt(input);
          
          switch (option){
              case 1:
             if (sentCount >= messageLimit){
             JOptionPane.showMessageDialog(null,"Message limit reached "); 
             break;
             }
             String receiver = 
             JOptionPane.showInputDialog("Enter receiver cell phone nmber(+contercode...):");
             String message = 
             JOptionPane.showInputDialog("Enter message (Max 250 characters)");
             
             if (message.length()>250) {
              JOptionPane.showMessageDialog(
               null,"Message exceeds 250 charaters by "+(message.length()- 300)+ "please reduce characters");
              break;
             }
             
             String[] options = {"Send message ", "Delete Message", "Store Message"};
             int choice;
             
              choice = JOptionPane.showOptionDialog(
                null,
                "Choose option:", 
                "Choose Action",
                 JOptionPane.DEFAULT_OPTION,
                 JOptionPane.INFORMATION_MESSAGE,
                 null,
                 options,
                 options[0]);
             
             String actionResult = "";
             switch (choice) {
                 case 0:
                     actionResult = Message.sendMessage("send");
                     sentCount++;
                     break;
                 case 1:
                     actionResult = Message.sendMessage("discard");
                     break;
                 case 2:
                     actionResult = Message.sendMessage("store");
                     break;
                 default:
                     actionResult = "No action taken.";
             }  
             JOptionPane.showMessageDialog(null,
                      "\n\nAction: " + actionResult);
             
             
             JOptionPane.showMessageDialog(null,
                     "Coming soon" );
             
             
             JOptionPane.showMessageDialog(null,"Total messages sent: " +
                     Message.returnTotalMessages() + "\nExiting QuickChatApp");
             System.exit(0);
             break;
             
              default:
                  JOptionPane.showMessageDialog(null,"Invalid option choose 1,2,3");
             }
          }
      }
    private static boolean login(){
        String username = JOptionPane.showInputDialog("Enter username");
        String password = JOptionPane.showInputDialog("Enter password");
        
        
        if (username != null && password != null && username.equals("username") && password.equals("jwiiwhdidh")) {
            JOptionPane.showMessageDialog(null, "Login successful");
        } else {
            JOptionPane.showMessageDialog(null, "Invalid username or password");
    }
        return false;
    }
}

        
