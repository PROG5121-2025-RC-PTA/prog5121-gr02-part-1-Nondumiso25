package Report;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class store {
    public static JSONArray loadItems(String store)throws IOException{
        String content = new String (Files.readAllBytes(Paths.get(store))); 
        return new JSONArray(content);
    }
    public static void searchItemsByName (JSONArray items, String name){
        boolean found = false;
        for (int i = 0; i < items.length(); i++){
           JSONObject item = items.getJSONObject(i);
           if (item.getString("name").equalsIgnoreCase(name)){
               System.out.println("Item found:"+ item.toString(2));
               found = true;
           }
        }
        if (!found){
            System.out.println("item with name"+ name + "not found");
        }
    }
    public static void main(String[]args){
        try{
            JSONArray items = loadItems("items.Json");
            
            searchItemsByName(items,"messageId");
         
        } catch (IOException e){
            System.out.println("Error readind JSON file"+ e.getMessage());
        }
    }
}


